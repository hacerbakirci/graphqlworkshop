public class GraphQLRequest
{
    public string Query { get; set; }
}